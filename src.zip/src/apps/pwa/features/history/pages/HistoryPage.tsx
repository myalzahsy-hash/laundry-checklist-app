import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAppConfigStore } from "@/shared/lib/config-store";
import { TransactionService } from "@/core/services/TransactionService";
import type { TransactionDocument } from "@/data/repositories/firestore/TransactionRepository";
import { TransactionCard } from "@/apps/pwa/features/history/components/TransactionCard";
import { SearchInput } from "@/apps/pwa/features/history/components/SearchInput";
import { Skeleton } from "@/ui/components/ui/skeleton";
import { Card, CardContent } from "@/ui/components/ui/card";
import { Package } from "lucide-react";

export default function HistoryPage() {
  const outletName = useAppConfigStore((s) => s.outletName);
  const navigate = useNavigate();

  const [transactions, setTransactions] = useState<TransactionDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");

  const fetchTransactions = useCallback(async () => {
    setLoading(true);
    setError(null);
    const result = await TransactionService.getAll(outletName);
    if (result.success) {
      setTransactions(result.data);
    } else {
      setError(result.error);
    }
    setLoading(false);
  }, [outletName]);

  useEffect(() => {
    fetchTransactions();
  }, [fetchTransactions]);

  const filtered = transactions.filter((t) => {
    const q = search.toLowerCase();
    return (
      t.receiptNumber.toLowerCase().includes(q) || t.customerName.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Riwayat</h2>

      <SearchInput
        value={search}
        onChange={setSearch}
        placeholder="Cari berdasarkan nomor nota atau nama..."
      />

      {loading && (
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-[72px] w-full rounded-lg" />
          ))}
        </div>
      )}

      {!loading && error && (
        <Card className="border-destructive/50">
          <CardContent className="p-4 text-center text-sm text-destructive">{error}</CardContent>
        </Card>
      )}

      {!loading && !error && filtered.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <Package className="mb-3 h-10 w-10 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">
            {search ? "Tidak ada transaksi yang cocok." : "Belum ada transaksi."}
          </p>
        </div>
      )}

      {!loading && !error && filtered.length > 0 && (
        <div className="space-y-2">
          {filtered.map((t) => (
            <TransactionCard
              key={t.id}
              receiptNumber={t.receiptNumber}
              customerName={t.customerName}
              transactionDate={t.transactionDate}
              totalItemCount={t.totalItemCount}
              onClick={() => navigate(`/riwayat/${t.id}`)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
